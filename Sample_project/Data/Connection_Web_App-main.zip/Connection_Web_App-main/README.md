# Connection_Web_App
This app acts as a connecting bridge between juniors, seniors and faculties for their respective institution.
